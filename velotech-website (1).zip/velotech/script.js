(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------- Loader ---------- */
  window.addEventListener('load', function () {
    setTimeout(function () { $('#loader').classList.add('hide'); startReveal(); }, 1700);
  });
  $('#year').textContent = new Date().getFullYear();

  /* ---------- Nav, progress, burger ---------- */
  var nav = $('#nav'), progress = $('#progress'), burger = $('#burger'), menu = $('#menu');
  window.addEventListener('scroll', function () {
    var h = document.documentElement;
    nav.classList.toggle('solid', window.scrollY > 40);
    progress.style.width = (window.scrollY / (h.scrollHeight - h.clientHeight) * 100) + '%';
  }, { passive: true });
  burger.addEventListener('click', function () {
    burger.classList.toggle('open'); menu.classList.toggle('open');
  });
  $$('#menu a').forEach(function (a) {
    a.addEventListener('click', function () { burger.classList.remove('open'); menu.classList.remove('open'); });
  });

  /* ---------- Custom cursor ---------- */
  var cur = $('#cursor');
  window.addEventListener('mousemove', function (e) {
    cur.style.left = e.clientX + 'px'; cur.style.top = e.clientY + 'px';
  });
  $$('a,button,.tilt').forEach(function (el) {
    el.addEventListener('mouseenter', function () { cur.classList.add('big'); });
    el.addEventListener('mouseleave', function () { cur.classList.remove('big'); });
  });

  /* ---------- Typing effect ---------- */
  var words = ['Website Development', 'App Development', 'UI / UX Design', 'Content Creation', 'Poster Design', 'Logo & Branding'];
  var wi = 0, ci = 0, del = false, typedEl = $('#typed');
  (function type() {
    var w = words[wi];
    typedEl.textContent = w.substring(0, ci);
    if (!del && ci < w.length) { ci++; setTimeout(type, 80); }
    else if (!del) { del = true; setTimeout(type, 1400); }
    else if (ci > 0) { ci--; setTimeout(type, 40); }
    else { del = false; wi = (wi + 1) % words.length; setTimeout(type, 300); }
  })();

  /* ---------- Scroll reveal + counters ---------- */
  function startReveal() {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.classList.add('in');
        var n = $('b[data-n]', en.target);
        if (n) count(n);
        io.unobserve(en.target);
      });
    }, { threshold: 0.12 });
    $$('.reveal').forEach(function (el, i) {
      el.style.transitionDelay = (i % 6) * 0.08 + 's';
      io.observe(el);
    });
  }
  function count(el) {
    var target = +el.dataset.n, cur = 0, step = Math.max(1, Math.round(target / 50));
    var t = setInterval(function () {
      cur += step;
      if (cur >= target) { cur = target; clearInterval(t); }
      el.textContent = cur;
    }, 30);
  }

  /* ---------- 3D tilt on cards ---------- */
  $$('.tilt').forEach(function (el) {
    el.addEventListener('mousemove', function (e) {
      var r = el.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      el.style.transform = 'perspective(900px) rotateX(' + ((0.5 - y) * 16) + 'deg) rotateY(' + ((x - 0.5) * 16) + 'deg) scale3d(1.03,1.03,1.03)';
      el.style.setProperty('--mx', (x * 100) + '%');
      el.style.setProperty('--my', (y * 100) + '%');
    });
    el.addEventListener('mouseleave', function () { el.style.transform = ''; });
  });

  /* ---------- Portfolio filter ---------- */
  $$('#filters button').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('#filters button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      var f = b.dataset.f;
      $$('#workGrid .proj').forEach(function (p) {
        p.classList.toggle('gone', f !== 'all' && p.dataset.c !== f);
      });
    });
  });

  /* ---------- Contact form (opens email app) ---------- */
  $('#form').addEventListener('submit', function (e) {
    e.preventDefault();
    var f = e.target;
    var subject = encodeURIComponent('New project enquiry — ' + f.service.value);
    var body = encodeURIComponent('Name: ' + f.name.value + '\nEmail: ' + f.email.value + '\nService: ' + f.service.value + '\n\n' + f.msg.value);
    $('#formNote').textContent = 'Opening your email app…';
    window.location.href = 'mailto:hello@velotech.in?subject=' + subject + '&body=' + body; // change to your email
  });

  /* ---------- Three.js 3D hero ---------- */
  if (typeof THREE === 'undefined') return;
  var canvas = $('#bg');
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  var scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x05060f, 0.035);
  var camera = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
  camera.position.z = 14;

  scene.add(new THREE.AmbientLight(0x6666ff, 0.6));
  var l1 = new THREE.PointLight(0x00e0ff, 2.2, 60); l1.position.set(10, 8, 10); scene.add(l1);
  var l2 = new THREE.PointLight(0xff5ca8, 2.2, 60); l2.position.set(-10, -6, 8); scene.add(l2);

  var group = new THREE.Group(); scene.add(group);

  // Main glass-like knot
  var knot = new THREE.Mesh(
    new THREE.TorusKnotGeometry(2.6, 0.75, 220, 32),
    new THREE.MeshStandardMaterial({ color: 0x6a5cff, metalness: 0.85, roughness: 0.18, emissive: 0x1a1260, emissiveIntensity: 0.6 })
  );
  group.add(knot);
  var wire = new THREE.Mesh(
    new THREE.TorusKnotGeometry(2.62, 0.78, 120, 16),
    new THREE.MeshBasicMaterial({ color: 0x00e0ff, wireframe: true, transparent: true, opacity: 0.18 })
  );
  group.add(wire);

  // Floating shapes
  var shapes = [], geos = [
    new THREE.IcosahedronGeometry(0.6, 0), new THREE.OctahedronGeometry(0.6), new THREE.BoxGeometry(0.8, 0.8, 0.8), new THREE.TorusGeometry(0.5, 0.18, 12, 28)
  ], cols = [0x00e0ff, 0xff5ca8, 0x6a5cff, 0xffd34d];
  for (var i = 0; i < 16; i++) {
    var m = new THREE.Mesh(geos[i % 4], new THREE.MeshStandardMaterial({ color: cols[i % 4], metalness: 0.7, roughness: 0.25 }));
    var a = Math.random() * Math.PI * 2, rad = 6 + Math.random() * 6;
    m.position.set(Math.cos(a) * rad, (Math.random() - 0.5) * 10, Math.sin(a) * rad - 4);
    m.userData = { s: 0.3 + Math.random() * 0.7, o: Math.random() * 6 };
    m.scale.setScalar(0.6 + Math.random() * 0.8);
    scene.add(m); shapes.push(m);
  }

  // Particle field
  var pg = new THREE.BufferGeometry(), N = 1400, pos = new Float32Array(N * 3);
  for (var j = 0; j < N * 3; j++) pos[j] = (Math.random() - 0.5) * 70;
  pg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  var pts = new THREE.Points(pg, new THREE.PointsMaterial({ color: 0x9aa8ff, size: 0.07, transparent: true, opacity: 0.8 }));
  scene.add(pts);

  var mx = 0, my = 0, sy = 0;
  window.addEventListener('mousemove', function (e) {
    mx = (e.clientX / window.innerWidth - 0.5) * 2; my = (e.clientY / window.innerHeight - 0.5) * 2;
  });
  window.addEventListener('scroll', function () { sy = window.scrollY; }, { passive: true });

  function resize() {
    var w = canvas.clientWidth, h = canvas.clientHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    group.position.x = w > 900 ? 4.2 : 0;
    group.position.y = w > 900 ? 0 : 3.2;
    group.scale.setScalar(w > 900 ? 1 : 0.7);
  }
  window.addEventListener('resize', resize); resize();

  var clock = new THREE.Clock(), visible = true;
  new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }).observe($('#home'));

  (function animate() {
    requestAnimationFrame(animate);
    if (!visible) return;
    var t = clock.getElapsedTime();
    knot.rotation.x = t * 0.25; knot.rotation.y = t * 0.35;
    wire.rotation.copy(knot.rotation);
    group.rotation.y += (mx * 0.5 - group.rotation.y) * 0.05;
    group.rotation.x += (my * 0.35 - group.rotation.x) * 0.05;
    shapes.forEach(function (m) {
      m.rotation.x += 0.005 * m.userData.s; m.rotation.y += 0.008 * m.userData.s;
      m.position.y += Math.sin(t * m.userData.s + m.userData.o) * 0.004;
    });
    pts.rotation.y = t * 0.012; pts.rotation.x = sy * 0.0004;
    camera.position.x += (mx * 1.2 - camera.position.x) * 0.04;
    camera.position.y += (-my * 0.8 - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
    renderer.render(scene, camera);
  })();
})();
